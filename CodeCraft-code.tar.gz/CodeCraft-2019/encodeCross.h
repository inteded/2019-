#pragma once
//#include"pch.h"
#include<iostream>
#include"ReadCrossInfo.h"
#include"ReadRoadInfo.h"
#include<vector>
using namespace std;
//void encodeCross(ReadCrossInfo readCrossFile, ReadRoadInfo readRoadfile);
vector<vector<int>> encodeFromCross(ReadCrossInfo readCrossFile, ReadRoadInfo readRoadfile);

vector<vector<int>> encodeToCross(ReadCrossInfo readCrossFile, ReadRoadInfo readRoadfile);

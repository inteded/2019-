
//#include "pch.h"


#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include "ReadRoadInfo.h"
#include "ReadCrossInfo.h"
#include "ReadCarInfo.h"
#include"dijkstra.h"
#include"encodeCross.h"
#include<algorithm>


using  namespace std;

//�����ո���ַ���ת��Ϊ����
bool sortfunc(vector<int> sorInfo)
{

	return true;
}

bool cmp(vector<int> a, vector<int> b)
{
	return (a[5] / a[6] + a[4]) < b[5] / b[6] + b[4];
	return true;
}

void buppleSort(vector<vector<int>> &carRunInfo)
{
	int i, j;
	vector<int> tmp;
	for (i = 0; i < carRunInfo.size(); i++)
	{
		for (j = 0; j < carRunInfo.size() - 1 - i; j++)
		{
			if (carRunInfo[i][5] / 2.0 < carRunInfo[i + 1][5] / 2.0)
			{
				tmp = carRunInfo[i];
				carRunInfo[i] = carRunInfo[i + 1];
				carRunInfo[i + 1] = tmp;
			}
		}
	}
}

int main(int argc, char *argv[])
{

	std::cout << "Begin" << std::endl;

	if (argc < 5) {
		std::cout << "please input args: carPath, roadPath, crossPath, answerPath" << std::endl;
		exit(1);
	}

	std::string carPath(argv[1]);
	std::string roadPath(argv[2]);
	std::string crossPath(argv[3]);
	std::string answerPath(argv[4]);

	ifstream roadPath1(roadPath);
	ifstream crossPath1(crossPath);
	ifstream carPath1(carPath);
	ReadRoadInfo readRoadfile(roadPath1); //��ȡ��·��Ϣ
	//readRoadfile.printRoadInfo(cout);

	ReadCrossInfo readCrossFile(crossPath1);//��ȡ·����Ϣ
	//readCrossFile.printCrossInfo(cout);
	ReadCarInfo readCarfile(carPath1);   //��ȡ������Ϣ
	//readCarfile.printCarInfo(cout);


	// Graph<string> G= generateGraph(readRoadfile); //�ڽӾ���

	// vector<vector<int>> calcLength =  readRoadfile.getIdLen();
	// //vector<int> speedLimit = readRoadfile.getSpeed();
	// //sort(speedLimit.begin(),speedLimit.end());
	// //int minSpeed = speedLimit[0];
	// vector<vector<int>> carRunInfo = getRoadId(readCarfile, G, calcLength);
	
	// int graphIdenti = readCarfile.getGraphIdenti();
	
	// int carStartupNum = 31;
	// if (graphIdenti == 19)
		// carStartupNum = 37; // 2
	// else
	// {
		// carStartupNum = 31;//   1
	// }

	// //for (int i = 0; i < 100; i++)
	// //{
	// //	for (int j = 0; j < carRunInfo[i].size(); j++)
	// //	{
	// //		cout << carRunInfo[i][j] << " ";
	// //	}
	// //	cout << endl;
	// //}

	// //����
	// //buppleSort(carRunInfo);//vector<int> [0]:carID [1]:carFrom [2]:carTo [3]:carSpeed [4]:carPlainTime [5]:carRoadLength
									  // //   [6]carPathLimitSpeed [7]....carRoadPath
	// //sort(carRunInfo.begin(), carRunInfo.end(), [&](const vector<int> &compa, const vector<int> &compb) { return (compa[5] / compa[6] + compa[4]+compa[1]) < compb[5] / compb[6] + compb[4]+compb[1]; });
	// sort(carRunInfo.begin(), carRunInfo.end(), [&](const vector<int> &compa, const vector<int> &compb) { return (compa[5] / compa[6]+compa[4]) < (compb[5] / compb[6] + compb[4]); });
	// cout << " �����ķ���ʱ�����" << endl;
	// //sort(carRunInfo.begin(), carRunInfo.end(), [&](const vector<int> &compa, const vector<int> &compb) {return compa[1] < compb[1]; });
	// for (int i = 0; i < 55; i++)
	// {

		// cout << carRunInfo[i][4] << " ";
		// //cout << endl;
	// }
	// cout << endl;
	// /*for (int i = 0; i < 100; i++)
	// {
		// for (int j = 0; j < carRunInfo[i].size(); j++)
		// {
			// cout << carRunInfo[i][j] << " ";
		// }
		// cout << endl;
	// }*/
	
	vector<vector<int>> form = encodeFromCross(readCrossFile, readRoadfile);
	vector<vector<int>> to = encodeToCross(readCrossFile, readRoadfile);
	for (size_t i = 0; i < form.size(); i++)
	{
		cout << form[i][0] << "\t " << to[i][0] << endl;
	}

	cout << "Ŀ�ĵأ�" << endl;

	/*for (size_t i = 0; i < to.size(); i++)
	{
		cout << to[i][0] << " " << to[i][1] << endl;
	}*/


	Graph<string> G= generateGraph(readRoadfile,form,to,readCrossFile); //�ڽӾ���

	vector<vector<int>> calcLength =  readRoadfile.getIdLen();
	////vector<int> speedLimit = readRoadfile.getSpeed();


	vector<vector<int>> carRunInfo = getRoadId(readCarfile, G, calcLength, readCrossFile);

	int graphIdenti = readCarfile.getGraphIdenti();

	cout << graphIdenti << endl;
	int carStartupNum = 35;
	if (graphIdenti == 426)
		carStartupNum == 37;
	else
	{
		carStartupNum = 35;
	}
	//buppleSort(carRunInfo);//vector<int> [0]:carID [1]:carFrom [2]:carTo [3]:carSpeed [4]:carPlainTime [5]:carRoadLength
									  //   [6]carPathLimitSpeed [7]....carRoadPath

	sort(carRunInfo.begin(), carRunInfo.end(), cmp);

	Scheduling(carRunInfo,carStartupNum);
	cout << "������ķ���ʱ�����£�"<<endl;
	for (int i = 0; i < 55; i++)
	{
		
			cout << carRunInfo[i][4] << " ";
			//cout << endl;
	}

	writeToTxt(carRunInfo,answerPath);

	std::cout << "carPath is " << carPath << std::endl;
	std::cout << "roadPath is " << roadPath << std::endl;
	std::cout << "crossPath is " << crossPath << std::endl;
	std::cout << "answerPath is " << answerPath << std::endl;
	//multimap<int, vector<int>> carInfo = readCarfile.getCarInfo_KeyPlaintime();
	//vector<vector<int>> carRoadPath = generatePath(G,readCarfile);
	//shuleding(carInfo, G);
	//outfile << ")" << endl;



	//vector<vector<int>> carRoadPath = generatePath(G,readCarfile);

	//multimap<int, vector<int>>::iterator carInfoPend = carInfo.end();
	//for (auto pStar = carInfo.begin();pStar!=carInfoPend;pStar++)
	//{
	//	cout << pStar->first << " ";
	//	vector<int>::iterator pend = pStar->second.end();
	//	for (vector<int>::iterator pstar = pStar->second.begin(); pstar != pend; pstar++)
	//	{
	//		//cout<<pStar->
	//		cout << *pstar << " ";
	//	}
	//	cout << endl;
	//}

	/*vector<vector<int>> carRoadPath = generatePath(G,readCarfile);
	
	for (int i = 0; i < 100; i++)
	{
		for (int j = 0; j < carRoadPath[i].size(); j++)
		{
			cout << carRoadPath[i][j] <<" ";
		}
		cout << endl;
	}*/
	//string path = Dijkstra(G, 64,1);
	////string arr =path.spl
	//vector<int> getId = string_to_int(G,path);

	//cout << " "<<endl;
	//cout << path << endl;
	//printG(G);

     system("pause");
     return 0;
 }






//#include"pch.h"
#include "ReadFileBuf.h"
#include <algorithm>

using namespace std;

bool aa(char text)
{
	if (text == '(' || text == ')' || text == ',')
			return true;
		else
			return false;
}

ReadFileBuf::ReadFileBuf(ifstream &ifs, shared_ptr<vector<vector<int>>> &Info) : input(new vector<string>)
{
	//һ��һ�ж�ȡ�����д���vector��
	for (string line; getline(ifs, line);)
	{
		if (line[0] == '#')
		{
			continue;
		}
		input->push_back(line);
		vector<int> vec;
		istringstream line_stream(line);
		for (string text, word; line_stream >> text; word.clear())
		{
			remove_copy_if(text.begin(), text.end(), back_inserter(word), aa);
			vec.push_back(stoi(word));
			
		}
		Info->push_back(vec);
	}
}


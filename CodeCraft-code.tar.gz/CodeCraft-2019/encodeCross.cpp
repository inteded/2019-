//#include"pch.h"
#include"encodeCross.h"
#include"ReadFileBuf.h"
#include"ReadCrossInfo.h"
#include"ReadRoadInfo.h"
#include<vector>
using namespace std;

vector<vector<int>> encodeFromCross(ReadCrossInfo readCrossFile, ReadRoadInfo readRoadfile)
{
	vector<vector<int>> crossIDencod =  readCrossFile.getCrossIdEncode(); // 0:���� 1��ID
	vector<vector<int>> from = readRoadfile.getFrom();

	for (size_t k = 0; k < crossIDencod.size(); k++)
	{
		cout << "encode:" << crossIDencod[k][0] << "  ID:" << crossIDencod[k][1]<< endl;
	}
	
	for (size_t i = 0; i < from.size(); i++)
	{
		for (size_t j = 0; j < crossIDencod.size(); j++)
		{
			if (from[i][0] == crossIDencod[j][1])
				from[i].push_back(crossIDencod[j][0]); //��ID�Ž�ȥ
		}
	}

	return from;
}


vector<vector<int>> encodeToCross(ReadCrossInfo readCrossFile, ReadRoadInfo readRoadfile)
{
	vector<vector<int>> crossIDencod = readCrossFile.getCrossIdEncode(); // 0:���� 1��ID
	cout << "zhelishi���ԣ�" << crossIDencod.size() << endl;
	vector<vector<int>> to = readRoadfile.getTo();

	for (size_t i = 0; i < to.size(); i++)
	{
		for (size_t j = 0; j < crossIDencod.size(); j++)
		{
			if (to[i][0] == crossIDencod[j][1])
				to[i].push_back(crossIDencod[j][0]); //��ID�Ž�ȥ
		}
	}
	cout << "crosssize:" << to.size()<<endl;
	return to;
}
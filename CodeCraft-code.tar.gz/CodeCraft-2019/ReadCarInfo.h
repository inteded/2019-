﻿#include "ReadFileBuf.h"
#include <iostream>

class ReadCarInfo
{
public:
	ReadCarInfo(ifstream &ifs) :carInfo(new vector<vector<int>>)
	{
		ReadFileBuf readfile(ifs, carInfo);
	}
	void printCarInfo(ostream &out)
	{
		for (auto &i : *carInfo)
		{
			for (auto &j : i)
			{
				out << j << " ";
			}
			cout << endl;
		}
	}

	//获取出发地
	vector<int> getFrom()
	{
		vector<int> From;
		for (int i = 0; i != carInfo->size(); ++i)
		{
			From.push_back(carInfo->at(i)[1]);
		}
		return From;
	}

	//获取目的地
	vector<int> getTo()
	{
		vector<int> To;
		for (int i = 0; i != carInfo->size(); ++i)
		{
			To.push_back(carInfo->at(i)[2]);
		}
		return To;
	}
	
	vector<int> getPlanTime()
	{
		vector<int> PlanTime;
		for (int i = 0; i != carInfo->size(); ++i)
		{
			PlanTime.push_back(carInfo->at(i)[2]);
		}
		return PlanTime;
	}

	vector<int> getCarId()
	{
		vector<int> CarId;
		for (int i = 0; i != carInfo->size(); ++i)
		{
			CarId.push_back(carInfo->at(i)[2]);
		}
		return CarId;
	}
	
	multimap<int, vector<int>> getCarInfo_KeyPlaintime()
	{
		multimap<int, vector<int>> KeyPlaintime;
		vector<int> carinfo(5,0);
		for (int i = 0; i != carInfo->size(); ++i)
		{
			//CarId.push_back(carInfo->at(i)[2]);
			carinfo[0] = carInfo->at(i)[0];
			carinfo[1] = carInfo->at(i)[1];
			carinfo[2] = carInfo->at(i)[2];
			carinfo[3] = carInfo->at(i)[3];
			KeyPlaintime.insert(make_pair(carInfo->at(i)[4], carinfo));
		}
		return KeyPlaintime;
	}

	vector<vector<int>> getCarInfo()
	{
		vector<vector<int>> CarInformation;
		vector<int> carinfo(5, 0);
		for (int i = 0; i != carInfo->size(); ++i)
		{
			//CarId.push_back(carInfo->at(i)[2]);
			carinfo[0] = carInfo->at(i)[0];//carID
			carinfo[1] = carInfo->at(i)[1];//car from
			carinfo[2] = carInfo->at(i)[2];//car to
			carinfo[3] = carInfo->at(i)[3];//car speed
			carinfo[4] = carInfo->at(i)[4];//car plainTime
			CarInformation.push_back(carinfo);
			
		}
		return CarInformation;
	}
	
	int getGraphIdenti()
	{
		return carInfo->at(0)[1];
	}


	
private:
	shared_ptr<vector<vector<int>>> carInfo;
};
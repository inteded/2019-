//#include"pch.h"
#include"ReadRoadInfo.h"
#include"ReadCarInfo.h"
#include"ReadCrossInfo.h"
#include"dijkstra.h"
#include<vector>
#include<string>
#include<sstream>

// Graph<string> generateGraph(ReadRoadInfo readRoadfile)
// {
	// //��ȡÿ��·�ĳ�����
	// vector<int> start = readRoadfile.getFrom();
	// //��ȡÿ��·���յ�   
	// vector<int> end = readRoadfile.getTo();
	// //��ȡÿ��·�ĳ���
	// vector<int> length = readRoadfile.getLength();
	// vector<int> isDuplex = readRoadfile.getisDuplex();
	// vector<int> ID = readRoadfile.getID();
	// vector<int> channel = readRoadfile.getChannel();



	// struct Graph<string> G;
	// //string temp[] = { "v0","v1","v2","v3","v4" };
	// /*int length = sizeof(temp) / sizeof(temp[0]);
	// G.vertexNum = length;
	// G.arcNum = 7;*/
	// G.vertexNum = MaxSize;//�������Ŀ
	// G.arcNum = start.size();//�ߵ�����
	// cout << G.arcNum << "," << G.vertexNum << endl;
	// //ifstream in("input.txt");
	// //in >> G.vertexNum >> G.arcNum;
	// // ��ʼ��ͼ�Ķ�����Ϣ
	// for (int i = 0; i < G.vertexNum; i++)
	// {
		// int tmp = 0;
		// tmp = i + 1;
		// G.vertex[i] = to_string(tmp);
	// }
	// //��ʼ��ͼG�ı�Ȩֵ  ���������֮��û�����ӣ������Ϊ�����MAXCOST
	// //�״γ�ʼ������Ϊ���еĵ�û������
	// for (int i = 0; i < G.vertexNum; i++)
	// {
		// for (int j = 0; j < G.vertexNum; j++)
		// {
			// G.arc[i][j].length = MAXCOST;
			// //cout << G.arc[i][j] << ",";
		// }
	// }

	// for (int i = 0; i < G.arcNum; i++)
	// {
		// if (isDuplex[i] == 1)
		// {
			// if (channel[i] <= 3)
			// {
				// G.arc[start[i] - 1][end[i] - 1].length = length[i];
				// G.arc[end[i] - 1][start[i] - 1].length = length[i];
			// }
			// else
			// {
				// G.arc[start[i] - 1][end[i] - 1].length = int(length[i] * 0.6);
				// G.arc[end[i] - 1][start[i] - 1].length = int(length[i] * 0.6);
				// //G.arc[start[i] - 1][end[i] - 1].length = length[i];
				// //G.arc[end[i] - 1][start[i] - 1].length = length[i];
			// }
			// // G.arc[start[i] - 1][end[i] - 1].length = 1;
			// // G.arc[end[i] - 1][start[i] - 1].length = 1;
			
			
			
			// G.arc[end[i] - 1][start[i] - 1].ID = ID[i]; //��·ID
			// G.arc[start[i] - 1][end[i] - 1].ID = ID[i];
		// }
		// else
		// {
			// G.arc[start[i] - 1][end[i] - 1].length = MAXCOST;
			// //G.arc[start[i] - 1][end[i] - 1].length = length[i];

			// G.arc[start[i] - 1][end[i] - 1].ID = ID[i];
		// }
	// }

	// return G;

// }
Graph<string> generateGraph(ReadRoadInfo readRoadfile, vector<vector<int>> start, vector<vector<int>> end,ReadCrossInfo readCrossFile)
{
	//��ȡÿ��·�ĳ�����
	//vector<int> start = readRoadfile.getFrom();
	//��ȡÿ��·���յ�   
	//vector<int> end = readRoadfile.getTo();
	
	//��ȡÿ��·�ĳ���
	vector<int> length = readRoadfile.getLength();
	vector<int> isDuplex = readRoadfile.getisDuplex();
	vector<int> ID = readRoadfile.getID();
	vector<int> channel = readRoadfile.getChannel();


	int MaxSize = readCrossFile.getCrossIdEncode().size();
	struct Graph<string> G;
	//string temp[] = { "v0","v1","v2","v3","v4" };
	G.vertexNum = MaxSize;//�������Ŀ
	G.arcNum = start.size();//�ߵ�����
	cout << G.arcNum << "," << G.vertexNum << endl;
	//ifstream in("input.txt");
	//in >> G.vertexNum >> G.arcNum;
	// ��ʼ��ͼ�Ķ�����Ϣ
	for (int i = 0; i < G.vertexNum; i++)
	{
		int tmp = 0;
		tmp = i + 1;
		G.vertex[i] = to_string(tmp);
	}
	//��ʼ��ͼG�ı�Ȩֵ  ���������֮��û�����ӣ������Ϊ�����MAXCOST
	//�״γ�ʼ������Ϊ���еĵ�û������
	for (int i = 0; i < G.vertexNum; i++)
	{
		for (int j = 0; j < G.vertexNum; j++)
		{
			G.arc[i][j].length = MAXCOST;
			//cout << G.arc[i][j] << ",";
		}
	}

	for (int i = 0; i < G.arcNum; i++)
	{
		if (isDuplex[i] == 1)
		{
			if (channel[i] <= 2)
			{
				G.arc[start[i][1] - 1][end[i][1] - 1].length = length[i];
				G.arc[end[i][1] - 1][start[i][1] - 1].length = length[i];
				//G.arc[end[i][1] - 1][start[i][1] - 1].ID = ID[i]; //��·ID
				//G.arc[start[i][1] - 1][end[i][1] - 1].ID = ID[i];
			}
			else
			{
				G.arc[start[i][1] - 1][end[i][1] - 1].length = int(length[i] * 0.5);
				G.arc[end[i][1] - 1][start[i][1] - 1].length = int(length[i] * 0.5);
			}

			//if()
			G.arc[end[i][1] - 1][start[i][1] - 1].ID = ID[i]; //��·ID
			G.arc[start[i][1] - 1][end[i][1] - 1].ID = ID[i];
		}
		else
		{
			G.arc[start[i][1] - 1][end[i][1] - 1].length = MAXCOST;

			G.arc[start[i][1] - 1][end[i][1] - 1].ID = ID[i];
		}
	}

	return G;

}

void printG(Graph<string> G)
{
	for (int i = 0; i < G.vertexNum; i++)
	{
		cout << "��" << i << "��" << endl;
		for (int j = 0; j < G.vertexNum; j++)
		{
			if (j % 10 == 0)
			{
				cout << endl;
			}
			//G.arc[i][j] = MAXCOST;
			cout << G.arc[i][j].ID << ",";
			if (j == 63)
				cout << endl;
		}

	}
}

// ���·��Dijkstra�㷨
string Dijkstra(Graph<string> G, int v,int desti)
{
	
	int MaxSize = G.vertexNum;
	v = v - 1;
	int pathFlag = 0;
	desti = desti - 1;

	int dist[MaxSize];//  i��j��·������
	string path[MaxSize];// ·���Ĵ�
	int s[MaxSize];// ���ҵ����·���ĵ�ļ���
	string pathID[MaxSize];
	bool Final[MaxSize];//Final[w]=1��ʾ��ö���V0��Vw�����·��
	// ��ʼ��dist\path
	for (int i = 0; i < G.vertexNum; i++)
	{
		Final[i] = false;
		dist[i] = G.arc[v][i].length;
		if (dist[i] != MAXCOST)
		{
			pathFlag=i;
			path[i] = G.vertex[v] + " " + G.vertex[i];
			/*if (pathFlag == v+2)
			{
				cout << " ��һ����:" << G.arc[v][i].ID << endl;
				cout << path[i]<<endl;
			}*/

			//cout << path[i] << endl;
			//pathID[i] = to_string(G.arc[v][i].ID);
		}
		//path[i] =G.vertex[i];
		else
			path[i] = " ";
	}
	//cout << " ��һ����:" << G.arc[v][pathFlag].ID << endl;

	s[0] = v; // ��ʼ��s
	Final[v] = true;
	int num = 1;
	while (num < G.vertexNum)
	{
		// ��dist�в�����СֵԪ��
		int k = 0, min = MAXCOST;
		for (int i = 0; i < G.vertexNum; i++)
		{
			if (i == v)continue;
			if (!Final[i] && dist[i] < min)
			{
				k = i;
				min = dist[i];
			}
		}
		//cout << "��" << k + 1 << "���·������Ϊ: " << dist[k] << "  ·��Ϊ��" << path[k] << endl;
		//cout << pathID << endl;
		if (desti == k )
			return path[k];
		//cout << dist[k] << path[k] << endl;
		//cout << path[k] << endl;
		s[num++] = k;// �������ɵĽ����뼯��s
		Final[k] = true;
		// �޸�dist��path����
		for (int i = 0; i < G.vertexNum; i++)
		{
			if (!Final[i] && dist[i] > dist[k] + G.arc[k][i].length)
			{
				dist[i] = dist[k] + G.arc[k][i].length;
				path[i] = path[k] + " " + G.vertex[i];
				//cout<< to_string(G.arc[k][i].ID)<<endl;
			}
		}
	}

	return " ";
	/*cout << "����������·Ϊ���£�" << endl;
	for(int i=0;i<MaxSize;i++)
	{
		cout << dist[i]<<" " ;
	}*/
}

vector<int> string_to_int(Graph<string> G,string path)
{

	//string path;
	stringstream ss(path);
	vector<int> vd;
	// Collect all real numbers.
	int temp;
	while (ss >> temp)
		vd.push_back(temp);
	vector<int> dbl_array;
	
	vector<int> pathID;
	//ȡ��·��ID
	for (int i = 0; i < vd.size() - 1; i++)
		pathID.push_back(G.arc[vd[i]-1][vd[i+1]-1].ID);
	//���·��ID
	/*for (int i = 0; i < pathID.size(); ++i)
		cout << pathID[i] << " ";*/
	return pathID;
	//return
}
//����·��
vector<vector<int>> generatePath(Graph<string> G, ReadCarInfo readCarfile)
{
	//Graph<string> G = generateGraph(readRoadfile); //�ڽӾ���
	vector<int> carFrom = readCarfile.getFrom();
	vector<int> carTo = readCarfile.getTo();
	vector<int> carId = readCarfile.getCarId();

	vector<vector<int>> carRoadPath;

	for (int i = 0; i < carFrom.size(); i++)
	{
		string path = Dijkstra(G, carFrom[i], carTo[i]);
		//vector<int> getId = string_to_int(G, path);
		carRoadPath.push_back(string_to_int(G, path));

	}
	

	return carRoadPath;
}

void shuleding(multimap<int, vector<int>> carInfo, Graph<string> G)
{

	/*vector<int> carFrom = readCarfile.getFrom();
	vector<int> carTo = readCarfile.getTo();*/
	ofstream outfile("answer.txt");
	if (!outfile)
	{
		cout << "Unable to open otfile";
		exit(1); // terminate with error
	}

	int k = 1;
	multimap<int, vector<int>>::iterator carInfoPend = carInfo.end();
	for (multimap<int, vector<int>>::iterator pStar = carInfo.begin(); pStar != carInfoPend; pStar++)
	{
		//int i = 0;
		
		outfile << "(" << pStar->second[0] << ",";
		outfile << k << ",";
		++k;
		string path = Dijkstra(G, pStar->second[1], pStar->second[2]);
		////string arr =path.spl
		vector<int> getId = string_to_int(G, path);

		int j = 0;
		for (vector<int>::iterator ibegin = getId.begin(); ibegin != getId.end(); ibegin++)
		{
			++j;
			if (j == 1)
				outfile << *ibegin << ",";
			else if (j < getId.size())
			{
				outfile << *ibegin << ",";
			}
			else
			{
				outfile << *ibegin << ")" << endl;
				j = 0;
			}
		}
	}
}

// vector<vector<int>> getRoadId(ReadCarInfo readCarfile, Graph<string> G, vector<vector<int>> calcLength)
// {
	// vector<vector<int>> carInfo = readCarfile.getCarInfo();
	// for (int i = 0; i < carInfo.size(); i++)
	// {
		// string path = Dijkstra(G,carInfo[i][1],carInfo[i][2]);
		// ////string arr =path.spl
		// vector<int> getId = string_to_int(G, path);
		
		// int len = 0;
		// int minSpeed = 1000;
		// for (int a = 0; a < calcLength.size(); a++)
		// {
			// ////������·�е��������
			
			// for (int b = 0; b < getId.size(); b++)
			// {
				
				// //��ȡ��·���ܳ���
				// if (getId[b] == calcLength[a][0])
				// {
					// len = len + calcLength[a][1];
					// if (minSpeed > calcLength[a][2])
						// minSpeed = calcLength[a][2];
				// }
				// else
				// {

				// }
			// }
		// }
		// carInfo[i].push_back(len);
		// carInfo[i].push_back(minSpeed);
		// minSpeed = 1000;
		// len = 0;
		// //��ȡ·���ĳ���
		// //int len = 0;
		// //for (int a = 0; a < 64; a++)
		// //{
		// //	for (int b = 0; b < 64; b++)
		// //	{
		// //		for (int c = 0; c < getId.size(); c++)
		// //		{
		// //			if (G.arc[a][b].ID == getId[c])
		// //				len = G.arc[a][b].length;
		// //			else
		// //			{
		// //			}
		// //		}
		// //		//G.arc[a][b].ID
		// //	}
		// //}

		// //carInfo[i].push_back(len);
		// //len = 0;
		// for (int j = 0; j < getId.size(); j++)
		// {
			// carInfo[i].push_back(getId[j]);
		// }
	// }
	
	// for (size_t i = 0; i < carInfo.size(); i++)
	// {
		// if (carInfo[i][3] < carInfo[i][6])
			// carInfo[i][6] = carInfo[i][3];
	// }

	// return carInfo;
	
// }

vector<vector<int>> getRoadId(ReadCarInfo readCarfile, Graph<string> G, vector<vector<int>> calcLength, ReadCrossInfo readCrossFile)
{
	vector<vector<int>> carInfo = readCarfile.getCarInfo();
	vector<vector<int>> crossIDencod = readCrossFile.getCrossIdEncode(); // 0:���� 1��ID
	for (int i = 0; i < carInfo.size(); i++)
	{
		int start = 0, end = 0;
		for (size_t k = 0; k < crossIDencod.size(); k++)
		{
			if (carInfo[i][1] == crossIDencod[k][1])
			       start= crossIDencod[k][0];
		}
		
		for (size_t w = 0; w < crossIDencod.size(); w++)
		{
			if (carInfo[i][2] == crossIDencod[w][1])
					end = crossIDencod[w][0];
		}
		string path = Dijkstra(G, start, end);
		//cout << path << endl;
		////string arr =path.spl
		vector<int> getId = string_to_int(G, path);
		
		//for (int p = 0; p < getId.size(); p++)
		//{
		//	cout << getId[p]<<" ";
		//}
		int len = 0;
		int minSpeed = 1000;
		for (int a = 0; a < calcLength.size(); a++)
		{
			////������·�е��������
			
			for (int b = 0; b < getId.size(); b++)
			{
				
				//��ȡ��·���ܳ���
				if (getId[b] == calcLength[a][0])
				{
					len = len + calcLength[a][1];
					if (minSpeed > calcLength[a][2])
						minSpeed = calcLength[a][2];
				}
				else
				{

				}
			}
		}
		carInfo[i].push_back(len);
		carInfo[i].push_back(minSpeed);
		minSpeed = 1000;
		len = 0;
		//��ȡ·���ĳ���
		//int len = 0;
		//for (int a = 0; a < 64; a++)
		//{
		//	for (int b = 0; b < 64; b++)
		//	{
		//		for (int c = 0; c < getId.size(); c++)
		//		{
		//			if (G.arc[a][b].ID == getId[c])
		//				len = G.arc[a][b].length;
		//			else
		//			{
		//			}
		//		}
		//		//G.arc[a][b].ID
		//	}
		//}

		//carInfo[i].push_back(len);
		//len = 0;
		for (int j = 0; j < getId.size(); j++)
		{
			carInfo[i].push_back(getId[j]);
		}
	}

	//���·�����ٺͳ���������С��һ��
	for (size_t i = 0; i < carInfo.size(); i++)
	{
		if (carInfo[i][3] < carInfo[i][6])
			carInfo[i][6] = carInfo[i][3];
	}

	return carInfo;
	
}

void Scheduling(vector<vector<int>>& carRunInfo,const int& carStartupNum)
{
	//ofstream outfile("answer.txt");
	//if (!outfile)
	//{
	//	cout << "Unable to open otfile";
	//	exit(1); // terminate with error
	//}
	
	// int carStartupNum = 0;
	// if (graphIdenti == 19)
	// {
		// carStartupNum = 37; // 2
	// }
	// else
	// {
		// carStartupNum = 31;//   1
	// }
	
	//��������ʱ��
	int cntCar = 0,j=0,time=1;
	while (carRunInfo.size()>cntCar)
	{
		for (int it = carStartupNum* j; it < (j + 1) * carStartupNum && it < carRunInfo.size(); it++)
		{
			if (carRunInfo[it][4] > time)
				time = carRunInfo[it][4];
			cntCar++;
			carRunInfo[it][4] = time;
		}

		time++; j++;
	}

	/*while (iTime<)
	{

	}*/
}

void writeToTxt(vector<vector<int>>& carRunInfo,string answerPath)
{
	ofstream outfile(answerPath);
	if (!outfile)
	{
		cout << "Unable to open otfile";
		exit(1); // terminate with error
	}

	for (auto iStar = carRunInfo.begin(); iStar != carRunInfo.end(); iStar++)
	{
		outfile << "(" << (*iStar)[0] << "," << (*iStar)[4]<<",";
		for (int i = 7; i < (*iStar).size(); i++)
		{
			if(i != (*iStar).size()-1)
				outfile << (*iStar)[i] << ",";
			else
			{
				outfile << (*iStar)[i] << ")";
			}
		}
		outfile << endl;
	}
}

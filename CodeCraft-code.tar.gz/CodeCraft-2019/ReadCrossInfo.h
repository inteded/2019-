﻿#pragma once
#include "ReadFileBuf.h"
#include <iostream>

class ReadCrossInfo
{
public:
	ReadCrossInfo(ifstream &ifs) :crossInfo(new vector<vector<int>>)
	{
		ReadFileBuf readfile(ifs, crossInfo);
	}
	void printCrossInfo(ostream &out)
	{
		for (auto &i : *crossInfo)
		{
			for (auto &j : i)
			{
				out << j << " ";
			}
			cout << endl;
		}
	}
	
	vector<vector<int>> getCrossIdEncode()
	{
		vector<vector<int>> CrossIdEncode;
		vector<int> Info(2,0);
		for (int i = 0; i <crossInfo->size(); ++i)
		{
			//CrossIdEncode.push_back(crossInfo->at(i)[4]);
			Info[0] = i+1;
			Info[1] = crossInfo->at(i)[0];
			CrossIdEncode.push_back(Info);
		}
		return CrossIdEncode;
	}
private:
	shared_ptr<vector<vector<int>>> crossInfo;
};
﻿#pragma once
#include<iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <memory>
#include<array>
#include <map>


using namespace std;

class ReadFileBuf
{
public:
	ReadFileBuf(ifstream &ifs, shared_ptr<vector<vector<int>>> &Info);

private:
	shared_ptr<vector<string>> input;
};
﻿#pragma once
#include "ReadFileBuf.h"
#include <iostream>

class ReadRoadInfo
{
public:
	ReadRoadInfo(ifstream &ifs) :roadInfo(new vector<vector<int>>)
	{
		ReadFileBuf readfile(ifs, roadInfo);
	}
	void printRoadInfo(ostream &out)
	{
		for (auto &i : *roadInfo)
		{
			for (auto &j : i)
			{
				out << j << " ";
			}
			cout << endl;
		}
	}

	vector<int> getLength()   //获得道路的长度
	{
		vector<int> length;
		for (int i = 0; i != roadInfo->size(); ++i)
		{
			length.push_back(roadInfo->at(i)[1]);
		}
		return length;
	}
	// vector<int> getFrom()  
	// {
		// vector<int> from;
		// for (int i = 0; i != roadInfo->size(); ++i)
		// {
			// from.push_back(roadInfo->at(i)[4]);
		// }
		// return from;
	// }
	// vector<int> getTo()
	// {
		// vector<int> to;
		// for (int i = 0; i != roadInfo->size(); ++i)
		// {
			// to.push_back(roadInfo->at(i)[5]);
		// }
		// return to;
	// }
	
	vector<vector<int>> getFrom()  
	{
		vector<vector<int>> from;
		for (int i = 0; i != roadInfo->size(); ++i)
		{
			vector<int> tmp;
			//from.push_back(roadInfo->at(i)[4]);
			tmp.push_back(roadInfo->at(i)[4]);
			from.push_back(tmp);
		}
		return from;
	}
	vector<vector<int>> getTo()
	{
		vector<vector<int>> to;
		for (int i = 0; i != roadInfo->size(); ++i)
		{
			vector<int> tmp;
			//from.push_back(roadInfo->at(i)[4]);
			tmp.push_back(roadInfo->at(i)[5]);
			to.push_back(tmp);
		}
		return to;
		/*vector<int> to;
		for (int i = 0; i != roadInfo->size(); ++i)
		{
			to.push_back(roadInfo->at(i)[5]);
		}
		return to;*/
	}
	vector<int> getisDuplex()
	{
		vector<int> isDuplex;
		for (int i = 0; i != roadInfo->size(); ++i)
		{
			isDuplex.push_back(roadInfo->at(i)[6]);
		}
		return isDuplex;
	}

	vector<int> getID()   //获得道路的ID,注意存取的方式，可能会产生溢出
	{
		vector<int> roadID;
		for (int i = 0; i != roadInfo->size(); ++i)
		{
			roadID.push_back(roadInfo->at(i)[0]);
		}
		return roadID;
	}

	vector<int> getSpeed()   //获得道路的ID,注意存取的方式，可能会产生溢出
	{
		vector<int> speed;
		for (int i = 0; i != roadInfo->size(); ++i)
		{
			speed.push_back(roadInfo->at(i)[2]);
		}
		return speed;
	}
	
	vector<int> getChannel()   //获得道路的channel,注意存取的方式，可能会产生溢出
	{
		vector<int> channel;
		for (int i = 0; i != roadInfo->size(); ++i)
		{
			channel.push_back(roadInfo->at(i)[3]);
		}
		return channel;
	}

	vector<vector<int>> getIdLen()
	{
		vector<vector<int>> idLen;

		vector<int> roadID(3,0);
		for (int i = 0; i != roadInfo->size(); ++i)
		{
			//roadID.push_back(roadInfo->at(i)[0]);
			//roadID.push_back(roadInfo->at(i)[1]);
			roadID[0] = roadInfo->at(i)[0];//id
			roadID[1] = roadInfo->at(i)[1];//length
			roadID[2] = roadInfo->at(i)[2];//limitSpeed
			idLen.push_back(roadID);
		}
		return idLen;
		
	}

private:
	shared_ptr<vector<vector<int>>> roadInfo;
};
//#pragma once
#include<string>
#define MaxSize1 200
#define MAXCOST 10000

class roadFromToId
{
public:
	roadFromToId()
	{
	}
	roadFromToId(int length,int id)
	{
		//this->From = form;
		//this->To = to;
		this->length = length;
		this->ID = id;
	}
public:
	//int From;
	//int To;
	int ID;
	int length;

};

// ͼ�Ľṹ
template < class T>
struct Graph
{
	T vertex[MaxSize1];// ���ͼ�ж��������
	roadFromToId arc[MaxSize1][MaxSize1];// ���ͼ�бߵ�����
	int vertexNum, arcNum;// ͼ�ж������ͱ���
};

//Graph<string> generateGraph(ReadRoadInfo readRoadfile, vector<vector<int>> start, vector<vector<int>> end);
Graph<string> generateGraph(ReadRoadInfo readRoadfile, vector<vector<int>> start, vector<vector<int>> end,ReadCrossInfo readCrossFile);

string Dijkstra(Graph<string> G, int v,int desti);

void printG(Graph<string> G);

vector<int> string_to_int(Graph<string> G, string path);

vector<vector<int>> generatePath(Graph<string> G, ReadCarInfo readCarfile);

void shuleding(multimap<int, vector<int>> carInfo, Graph<string> G);

//vector<vector<int>> getRoadId(ReadCarInfo readCarfile, Graph<string> G, vector<vector<int>> calcLength );
vector<vector<int>> getRoadId(ReadCarInfo readCarfile, Graph<string> G, vector<vector<int>> calcLength, ReadCrossInfo readCrossFile);

void Scheduling(vector<vector<int>>& carRunInfo,const int& carStartupNum);
void writeToTxt(vector<vector<int>>& carRunInfo,string answerPath);
